<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Ebill;
use App\Models\EbillExpenses;
use App\Models\EbillProducts;
use App\Models\EbillBelongsManyProducts;
use Illuminate\Http\Request;

class EbillController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $perameters     = $request->all();
        // echo "<pre>";print_r($perameters);die;
        $user_id        = $request->input('user_id');
        $vendor_id      = $request->input('vendor_id');
        $role_id        = $request->input('role_id');
        $offset         = $request->input('offset');
        $limit          = $request->input('limit');
        $column_name    = $request->input('column_name');
        $sort_by        = $request->input('sort_by');
        $seller_type    = $request->input('seller_type');
        if(!empty($seller_type) && $seller_type == '1' ){
            // get list of user ebills
            $ebills = Ebill::with(['user'])
            ->where('user_id', $user_id)
            ->offset($offset)
            ->limit($limit)
            ->orderBy($column_name, $sort_by)
            ->get();
            // get total count of user ebills
            $total_count = Ebill::where('user_id', $user_id)->count();
        }else{
            // get list of vendor ebills
            $ebills = Ebill::with(['vendor'])
            ->where('vendor_id', $vendor_id)
            ->offset($offset)
            ->limit($limit)
            ->orderBy($column_name, $sort_by)
            ->get();
            // get total count of vendor ebills
            $total_count = Ebill::where('vendor_id', $vendor_id)->count();
        }


        if($ebills){
            $data = ['status' => true, 'code' => 200, 'ebills' => $ebills, 'total_count'=>$total_count];
        }else{
            $data = ['status' => false, 'code' => 404, 'msg' => 'data not found'];
        }
        return $data;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $perameters = $request->all();
        $order_id = 'AS'.date("Ymd").'-'.rand(10000, 99999);
        $bill_number = time();
        $ebill = new Ebill();
        $ebill->user_id         = $perameters['user_id'];
        $ebill->vendor_id       = $perameters['vendor_id'];
        $ebill->order_id        = $order_id;
        $ebill->bill_number     = $bill_number;
        $ebill->specification   = ($perameters['specification']) ? $perameters['specification'] : '';
        $ebill->ship_to         = ($perameters['ship_to']) ? $perameters['ship_to'] : '';
        $ebill->bill_to         = ($perameters['bill_to']) ? $perameters['bill_to'] : '';
        $ebill->bill_date       = $perameters['bill_date'];
        $ebill->due_date        = $perameters['due_date'];
        $ebill->advance_amount  = ($perameters['advance_amount']) ? $perameters['advance_amount'] : 0;
        $ebill->due_amount      = ($perameters['due_amount']) ? $perameters['due_amount'] : 0;
        $ebill->total_amount    = $perameters['total_amount'];
        $ebill->status          = ($perameters['status']) ? $perameters['status'] : '1';
        $ebill->seller_type     = ($perameters['seller_type']) ? $perameters['seller_type'] : '1';
        $res = $ebill->save();
        if($res){
            // Insert Ebill Expenses
            $ebill_expense = new EbillExpenses();
            $ebill_expense->ebill_id        = $ebill->id;
            $ebill_expense->shipping_charge = $perameters['shipping_charge'];
            $ebill_expense->bank_charge     = $perameters['bank_charge'];
            $ebill_expense->mandi_tax       = $perameters['mandi_tax'];
            $ebill_expense->other_expense   = $perameters['other_expense'];
            $ebill_expense->save();
            // Corelate Ebill and thier products
            $products   = ($perameters['products']) ? $perameters['products'] : '';
            if(!empty($products)){
                $product_arr = explode(',', $products);
                if(!empty($product_arr)){
                    $product_data = [];
                    foreach ($product_arr as $product) {
                        $row = [];
                        $row['ebill_id'] = $ebill->id;
                        $row['ebill_product_id'] = $product;
                        $row['created_at'] = date('Y-m-d H:i:s');
                        $row['updated_at'] = date('Y-m-d H:i:s');
                        $product_data[] = $row;
                    }
                    EbillBelongsManyProducts::insert($product_data);
                }
            }
            $data = ['status' => true, 'code' => 200, 'ebill' => $ebill];
        }else{
            $data = ['status' => false, 'code' => 500];
        }
        return $data;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Ebill  $ebill
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ebill = Ebill::with(['user', 'vendor', 'products'])->where('id', $id)->first();
        if($ebill){
            return ['status' => true, 'code' => 200, 'data'=>$ebill];
        }else{
            return ['status' => false, 'code' => 404, 'message' => "data not found"];
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Ebill  $ebill
     * @return \Illuminate\Http\Response
     */
    public function edit(Ebill $ebill)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Ebill  $ebill
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Ebill $ebill)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Ebill  $ebill
     * @return \Illuminate\Http\Response
     */
    public function destroy(Ebill $ebill)
    {
        //
    }

    /**
     * Remove the Ebill product from storage.
     *
     * @param  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteProduct($id)
    {
        $ebill_product = EbillProducts::find($id);
        if($ebill_product){
            $res = $ebill_product->delete();
            if($res){
                return ['status' => true, 'code' => 200, 'message' => "data deleted success"];
            }else{
                return ['status' => false, 'code' => 500, 'message' => "something went wrong with database."];
            }
        }else{
            return ['status' => false, 'code' => 404, 'message' => "data not found"];
        }
    }

    /**/
    public function addProduct(Request $request){
        $ebill_product = new EbillProducts;
        $ebill_product->category_id     = $request->input('category_id');
        $ebill_product->subcategory_id  = $request->input('subcategory_id');
        $ebill_product->commodity_id    = $request->input('commodity_id');
        $ebill_product->product_name    = $request->input('product_name');
        $ebill_product->packet_number   = $request->input('packet_number');
        $ebill_product->total_volume    = ($request->input('total_volume')) ? $request->input('total_volume') : 0;
        $ebill_product->volume_unit     = ($request->input('volume_unit')) ? $request->input('volume_unit') : '';
        $ebill_product->product_rate    = $request->input('product_rate');
        $ebill_product->rate_unit       = $request->input('rate_unit');
        $ebill_product->product_tax     = ($request->input('product_tax')) ? $request->input('product_tax') : 0;
        $ebill_product->product_image   = $request->input('product_image');
        $ebill_product->specification   = $request->input('specification');
        $ebill_product->subtotal        = $request->input('subtotal');
        // upload product file / video
        $file = $request->file('product_image');
        if($file){
            $filename   = $file->getClientOriginalName();
            $name       = "ebill_product";
            $extension  = $file->extension();
            $filenew    =  date('d-M-Y').'_'.str_replace($filename,$name,$filename).'_'.time().''.rand(). "." .$extension;
            $file->move(base_path('/public/uploads/products'), $filenew);
            $ebill_product->product_image   = asset('/uploads/products/'.$filenew);
        }
        $ebill_product->status = $request->input('status');
        $res = $ebill_product->save();
        if($res){
            return ['status' => true, 'code' => 200, 'data'=>$ebill_product];
        }else{
            return ['status' => false, 'code' => 500, 'message' => "something went wrong with database."];
        }
    }
}
