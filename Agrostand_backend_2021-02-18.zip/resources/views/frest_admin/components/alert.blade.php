<div class="alert alert-{{ $type }} alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><span class="icon fa fa-check"></span>{{ $slot }}</h4>
</div>